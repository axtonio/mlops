from ._core import rgb_to_gray

__all__ = ["rgb_to_gray"]

